<?php

/**
 * This file is part of the CodeIgniter 4 framework.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace CodeIgniter\Session\Handlers;

use CodeIgniter\Session\Exceptions\SessionException;
use Config\App as AppConfig;
use Exception;

/**
 * Session handler using file system for storage
 */
class FileHandler extends BaseHandler
{
    protected $savePath;
    protected $fileHandle;
    protected $filePath;
    protected $fileNew;
    protected $matchIP = false;
    protected $sessionIDRegex = '';

    public function __construct(AppConfig $config, string $ipAddress)
    {
        parent::__construct($config, $ipAddress);

        if (! empty($config->sessionSavePath)) {
            $this->savePath = rtrim($config->sessionSavePath, '/\\');
            ini_set('session.save_path', $config->sessionSavePath);
        } else {
            $sessionPath = rtrim(ini_get('session.save_path'), '/\\');
            if (! $sessionPath) {
                $sessionPath = WRITEPATH . 'session';
            }
            $this->savePath = $sessionPath;
        }

        $this->matchIP = $config->sessionMatchIP;
        $this->configureSessionIDRegex();
    }

    #[\ReturnTypeWillChange]
    public function open($savePath, $name): bool
    {
        if (! is_dir($savePath)) {
            if (! mkdir($savePath, 0700, true)) {
                throw SessionException::forInvalidSavePath($this->savePath);
            }
        } elseif (! is_writable($savePath)) {
            throw SessionException::forWriteProtectedSavePath($this->savePath);
        }

        $this->savePath = $savePath;
        $this->filePath = $this->savePath . '/' . $name . ($this->matchIP ? md5($this->ipAddress) : '');

        return true;
    }

    #[\ReturnTypeWillChange]
    public function read($sessionID): string|false
    {
        if ($this->fileHandle === null) {
            $this->fileNew = ! is_file($this->filePath . $sessionID);

            if (($this->fileHandle = fopen($this->filePath . $sessionID, 'c+b')) === false) {
                $this->logger->error("Session: Unable to open file '" . $this->filePath . $sessionID . "'.");
                return false;
            }

            if (flock($this->fileHandle, LOCK_EX) === false) {
                $this->logger->error("Session: Unable to obtain lock for file '" . $this->filePath . $sessionID . "'.");
                fclose($this->fileHandle);
                $this->fileHandle = null;
                return false;
            }

            if (is_null($this->sessionID)) {
                $this->sessionID = $sessionID;
            }

            if ($this->fileNew) {
                chmod($this->filePath . $sessionID, 0600);
                $this->fingerprint = md5('');
                return '';
            }
        } else {
            rewind($this->fileHandle);
        }

        $sessionData = '';
        clearstatcache();
        $filesize = filesize($this->filePath . $sessionID);
        
        if ($filesize > 0) {
            for ($read = 0; $read < $filesize; $read += strlen($buffer)) {
                if (($buffer = fread($this->fileHandle, $filesize - $read)) === false) {
                    break;
                }
                $sessionData .= $buffer;
            }
        }

        $this->fingerprint = md5($sessionData);
        return $sessionData;
    }

    #[\ReturnTypeWillChange]
    public function write($sessionID, $sessionData): bool
    {
        if ($sessionID !== $this->sessionID) {
            $this->sessionID = $sessionID;
        }

        if (! is_resource($this->fileHandle)) {
            return false;
        }

        if ($this->fingerprint === md5($sessionData)) {
            return ($this->fileNew) ? true : touch($this->filePath . $sessionID);
        }

        if (! $this->fileNew) {
            ftruncate($this->fileHandle, 0);
            rewind($this->fileHandle);
        }

        $result = 0;
        if (($length = strlen($sessionData)) > 0) {
            for ($written = 0; $written < $length; $written += $result) {
                if (($result = fwrite($this->fileHandle, substr($sessionData, $written))) === false) {
                    break;
                }
            }

            if (! is_int($result)) {
                $this->fingerprint = md5(substr($sessionData, 0, $written));
                $this->logger->error('Session: Unable to write data.');
                return false;
            }
        }

        $this->fingerprint = md5($sessionData);
        return true;
    }

    #[\ReturnTypeWillChange]
    public function close(): bool
    {
        if (is_resource($this->fileHandle)) {
            flock($this->fileHandle, LOCK_UN);
            fclose($this->fileHandle);
            $this->fileHandle = null;
            $this->fileNew    = false;
        }
        return true;
    }

    #[\ReturnTypeWillChange]
    public function destroy($sessionId): bool
    {
        if ($this->close()) {
            return is_file($this->filePath . $sessionId)
                ? (unlink($this->filePath . $sessionId) && $this->destroyCookie()) : true;
        }

        if ($this->filePath !== null) {
            clearstatcache();
            return is_file($this->filePath . $sessionId)
                ? (unlink($this->filePath . $sessionId) && $this->destroyCookie()) : true;
        }

        return false;
    }

    #[\ReturnTypeWillChange]
    public function gc($maxlifetime): int|false
    {
        if (! is_dir($this->savePath) || ($directory = opendir($this->savePath)) === false) {
            return false;
        }

        $ts = time() - $maxlifetime;
        $pattern = $this->matchIP === true ? '[0-9a-f]{32}' : '';
        $pattern = sprintf('#\A%s' . $pattern . $this->sessionIDRegex . '\z#', preg_quote($this->cookieName));

        $count = 0;
        while (($file = readdir($directory)) !== false) {
            if (! preg_match($pattern, $file)
                || ! is_file($this->savePath . DIRECTORY_SEPARATOR . $file)
                || ($mtime = filemtime($this->savePath . DIRECTORY_SEPARATOR . $file)) === false
                || $mtime > $ts
            ) {
                continue;
            }
            unlink($this->savePath . DIRECTORY_SEPARATOR . $file);
            $count++;
        }

        closedir($directory);
        return $count;
    }

    protected function configureSessionIDRegex()
    {
        $bitsPerCharacter = (int) ini_get('session.sid_bits_per_character');
        $SIDLength        = (int) ini_get('session.sid_length');

        if (($bits = $SIDLength * $bitsPerCharacter) < 160) {
            $SIDLength += (int) ceil((160 % $bits) / $bitsPerCharacter);
            ini_set('session.sid_length', (string) $SIDLength);
        }

        switch ($bitsPerCharacter) {
            case 4: $this->sessionIDRegex = '[0-9a-f]'; break;
            case 5: $this->sessionIDRegex = '[0-9a-v]'; break;
            case 6: $this->sessionIDRegex = '[0-9a-zA-Z,-]'; break;
        }

        $this->sessionIDRegex .= '{' . $SIDLength . '}';
    }
}